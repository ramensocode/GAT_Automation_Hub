"""
Query execution and result handling for Snowflake operations.
Implements QueryTask and ResultSet entities from data-model.md.
"""

import time
import json
import csv
import yaml
from typing import List, Dict, Any, Optional, Union
from enum import Enum
from io import StringIO
from datetime import datetime, date

from .logging import configure_logging, log_query_execution
from .connection import SnowflakeConnection
from .validation import SnowflakeValidator
from .parameters import validate_parameters, detect_sql_injection_risk, convert_to_snowflake_format


class OperationType(Enum):
    """SQL operation types."""
    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    MERGE = "MERGE"
    DDL = "DDL"
    UNKNOWN = "UNKNOWN"


class OutputFormat(Enum):
    """Query result output formats."""
    JSON = "json"
    CSV = "csv"
    YAML = "yaml"


class ResultSet:
    """
    Represents query execution output.
    
    Implements data-model.md ResultSet entity with:
    - rows: Query result rows as list of dictionaries
    - column_metadata: Schema information for result columns
    - row_count: Number of rows affected/returned
    - execution_time_ms: Query execution duration
    - warnings: Non-fatal warnings from Snowflake
    - query_id: Snowflake query ID for debugging
    - changed: Ansible changed status
    """
    
    def __init__(
        self,
        rows: Optional[List[Dict[str, Any]]] = None,
        column_metadata: Optional[List[Dict[str, Any]]] = None,
        row_count: int = 0,
        execution_time_ms: int = 0,
        warnings: Optional[List[str]] = None,
        query_id: Optional[str] = None,
        changed: bool = False
    ):
        """
        Initialize ResultSet.
        
        Args:
            rows: Query result rows (for SELECT operations)
            column_metadata: Column schema information
            row_count: Number of rows affected/returned
            execution_time_ms: Execution duration in milliseconds
            warnings: List of warning messages
            query_id: Snowflake query ID
            changed: Ansible changed status (true for writes)
        """
        self.rows = rows or []
        self.column_metadata = column_metadata or []
        self.row_count = row_count
        self.execution_time_ms = execution_time_ms
        self.warnings = warnings or []
        self.query_id = query_id
        self.changed = changed
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert ResultSet to dictionary for Ansible module return.
        
        Returns:
            Dictionary with all result metadata
        """
        result = {
            'changed': self.changed,
            'row_count': self.row_count,
            'execution_time_ms': self.execution_time_ms,
        }
        
        if self.query_id:
            result['query_id'] = self.query_id
        
        if self.rows:
            result['rows'] = self.rows
        
        if self.column_metadata:
            result['column_metadata'] = self.column_metadata
        
        if self.warnings:
            result['warnings'] = self.warnings
        
        return result
    
    def format_output(self, output_format: OutputFormat) -> str:
        """
        Format result rows in specified output format.
        
        Args:
            output_format: Desired output format (json, csv, yaml)
        
        Returns:
            Formatted string representation of rows
        """
        if not self.rows:
            return ""
        
        if output_format == OutputFormat.JSON:
            return json.dumps(self.rows, indent=2, default=str)
        
        elif output_format == OutputFormat.CSV:
            output = StringIO()
            if self.rows:
                writer = csv.DictWriter(output, fieldnames=self.rows[0].keys())
                writer.writeheader()
                writer.writerows(self.rows)
            return output.getvalue()
        
        elif output_format == OutputFormat.YAML:
            return yaml.dump(self.rows, default_flow_style=False, allow_unicode=True)
        
        else:
            raise ValueError(f"Unsupported output format: {output_format}")
    
    def write_to_file(self, filepath: str, output_format: OutputFormat) -> None:
        """
        Write results to file (for large result sets per FR-013).
        
        Args:
            filepath: Path to output file
            output_format: Output format (json, csv, yaml)
        """
        formatted_output = self.format_output(output_format)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(formatted_output)


class QueryTask:
    """
    Represents a single SQL operation with configuration.
    
    Implements data-model.md QueryTask entity with:
    - query: SQL query text
    - operation_type: Derived operation type (SELECT, INSERT, etc.)
    - parameters: Named parameters for parameterization
    - output_format: Result format (json, csv, yaml)
    - output_file: File path for large result sets
    """
    
    # Threshold for streaming results to file (FR-013)
    LARGE_RESULT_THRESHOLD = 10000
    
    def __init__(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
        output_format: str = "json",
        output_file: Optional[str] = None,
        timeout: int = 30,
        log_level: str = "INFO",
        operation: Optional[str] = None,
        transaction_mode: str = "auto",
        validate_data: bool = True
    ):
        """
        Initialize QueryTask.
        
        Args:
            query: SQL query text
            parameters: Named parameters for query
            output_format: Output format (json, csv, yaml)
            output_file: Path to write results
            timeout: Query timeout in seconds
            log_level: Logging level
            operation: Explicit operation type (auto-detected if None)
            transaction_mode: Transaction mode ('auto' or 'manual')
            validate_data: Whether to validate data before write operations
        """
        if not query:
            raise ValueError("query must not be empty")
        
        self.query = query.strip()
        self.parameters = parameters or {}
        self.output_format = OutputFormat(output_format.lower())
        self.output_file = output_file
        self.timeout = timeout
        self.transaction_mode = transaction_mode
        self.validate_data = validate_data
        self._logger = configure_logging(log_level)
        
        self._logger.info(f"QueryTask initialized with {len(self.parameters)} parameters: {list(self.parameters.keys())}")
        
        # Convert query to Snowflake parameter format first
        self.query = convert_to_snowflake_format(self.query)
        
        # Validate parameters for SQL injection prevention (FR-005, T052, T053)
        # Pass query to check for missing parameters
        validate_parameters(self.parameters, self.query)
        
        # Detect SQL injection risks and log warnings
        injection_warnings = detect_sql_injection_risk(self.query, self.parameters)
        for warning in injection_warnings:
            self._logger.warning(f"SQL injection risk: {warning}")
        
        # Derive or use explicit operation type
        if operation:
            self.operation_type = OperationType[operation.upper()]
        else:
            self.operation_type = self._derive_operation_type()
    
    def _derive_operation_type(self) -> OperationType:
        """
        Derive operation type from first SQL keyword.
        
        Returns:
            OperationType enum value
        """
        first_word = self.query.split()[0].upper()
        
        try:
            return OperationType[first_word]
        except KeyError:
            if first_word in ['CREATE', 'ALTER', 'DROP', 'TRUNCATE']:
                return OperationType.DDL
            return OperationType.UNKNOWN
    
    def execute(self, connection: SnowflakeConnection) -> ResultSet:
        """
        Execute query and return results.
        
        Implements FR-002 (SELECT queries), FR-003 (write operations),
        FR-004 (output formats), FR-009 (transaction control),
        FR-011 (query timeout), FR-013 (large result streaming),
        FR-017 (data validation).
        
        Args:
            connection: Active Snowflake connection
        
        Returns:
            ResultSet with query results and metadata
        
        Raises:
            Exception: Query execution errors
        """
        start_time = time.time()
        is_write_operation = self.operation_type in [
            OperationType.INSERT,
            OperationType.UPDATE,
            OperationType.DELETE,
            OperationType.MERGE
        ]
        
        try:
            with connection.cursor(dictionary=True) as cursor:
                # Set statement timeout
                cursor.execute(f"ALTER SESSION SET STATEMENT_TIMEOUT_IN_SECONDS = {self.timeout}")
                
                # Begin transaction for auto mode write operations (FR-009)
                if is_write_operation and self.transaction_mode == 'auto':
                    cursor.execute("BEGIN")
                    self._logger.debug("Started automatic transaction")
                
                # Validate data before write operations (FR-017)
                if is_write_operation and self.validate_data:
                    self._validate_write_operation(cursor)
                
                # Execute query
                self._logger.debug(f"Executing {self.operation_type.value} query")
                self._logger.debug(f"Query: {self.query}")
                self._logger.debug(f"Parameters: {self.parameters}")
                
                # Execute with parameters if provided
                if self.parameters:
                    cursor.execute(self.query, self.parameters)
                else:
                    cursor.execute(self.query)
                
                # Get query ID for debugging
                query_id = cursor.sfqid
                
                # Collect results for SELECT operations
                rows = []
                column_metadata = []
                
                if self.operation_type == OperationType.SELECT:
                    # Fetch all results
                    rows = cursor.fetchall()
                    
                    # Extract column metadata
                    if cursor.description:
                        column_metadata = [
                            {
                                'name': col[0],
                                'type': col[1].__name__ if hasattr(col[1], '__name__') else str(col[1]) if col[1] else 'unknown',
                                'nullable': True  # Snowflake doesn't provide this in cursor
                            }
                            for col in cursor.description
                        ]
                    
                    row_count = len(rows)
                    changed = False
                else:
                    # Write operations - get affected row count
                    row_count = cursor.rowcount
                    # Idempotency: changed=true only if rows affected (FR-007)
                    changed = row_count > 0
                
                # Commit transaction for auto mode write operations (FR-009)
                if is_write_operation and self.transaction_mode == 'auto':
                    cursor.execute("COMMIT")
                    self._logger.debug(f"Committed transaction, {row_count} rows affected")
                
                # Calculate execution time
                execution_time_ms = int((time.time() - start_time) * 1000)
                
                # Create result set
                result = ResultSet(
                    rows=rows,
                    column_metadata=column_metadata,
                    row_count=row_count,
                    execution_time_ms=execution_time_ms,
                    query_id=query_id,
                    changed=changed
                )
                
                # Log execution metrics
                log_query_execution(
                    self._logger,
                    query_id=query_id,
                    execution_time_ms=execution_time_ms,
                    row_count=row_count,
                    operation=self.operation_type.value
                )
                
                # Stream large result sets to file (FR-013)
                if self.output_file and len(rows) > self.LARGE_RESULT_THRESHOLD:
                    self._logger.info(
                        f"Large result set ({len(rows)} rows), streaming to {self.output_file}"
                    )
                    result.write_to_file(self.output_file, self.output_format)
                    # Clear rows from memory
                    result.rows = []
                
                return result
                
        except Exception as e:
            execution_time_ms = int((time.time() - start_time) * 1000)
            self._logger.error(f"Query execution failed after {execution_time_ms}ms: {e}")
            
            # Rollback transaction for auto mode write operations (FR-009)
            if is_write_operation and self.transaction_mode == 'auto':
                try:
                    with connection.cursor() as cursor:
                        cursor.execute("ROLLBACK")
                        self._logger.warning("Transaction rolled back due to error")
                except Exception as rollback_error:
                    self._logger.error(f"Rollback failed: {rollback_error}")
            
            raise
    
    def _validate_write_operation(self, cursor) -> None:
        """
        Validate data before write operations (FR-017).
        
        Extracts table name from query and validates data compatibility.
        
        Args:
            cursor: Snowflake cursor for validation queries
        
        Raises:
            ValueError: Validation failures
        """
        # Extract table name from query (basic parsing)
        table_name = self._extract_table_name()
        
        if not table_name:
            self._logger.warning("Could not extract table name for validation, skipping")
            return
        
        # Use validator to check data compatibility
        validator = SnowflakeValidator()
        
        # For INSERT/UPDATE with VALUES clause, extract values
        if self.operation_type in [OperationType.INSERT, OperationType.UPDATE]:
            # Note: Full validation requires parsing VALUES clause
            # For now, fetch schema to ensure table exists
            # Pass table_name as-is (handles fully qualified names)
            schema = validator.fetch_table_schema(cursor, table_name, use_fully_qualified=True)
            if not schema:
                raise ValueError(f"Table {table_name} not found or inaccessible")
            
            self._logger.debug(f"Validated table {table_name} schema: {len(schema)} columns")
    
    def _extract_table_name(self) -> Optional[str]:
        """
        Extract table name from SQL query.
        
        Returns:
            Table name or None if not found
        """
        query_upper = self.query.upper()
        
        if self.operation_type == OperationType.INSERT:
            # INSERT INTO table_name ...
            if 'INTO' in query_upper:
                parts = self.query.split()
                try:
                    into_idx = [p.upper() for p in parts].index('INTO')
                    if into_idx + 1 < len(parts):
                        table_name = parts[into_idx + 1].split('(')[0].strip()
                        return table_name
                except (ValueError, IndexError):
                    pass
        
        elif self.operation_type == OperationType.UPDATE:
            # UPDATE table_name SET ...
            parts = self.query.split()
            if len(parts) >= 2:
                table_name = parts[1].split()[0].strip()
                return table_name
        
        elif self.operation_type == OperationType.DELETE:
            # DELETE FROM table_name ...
            if 'FROM' in query_upper:
                parts = self.query.split()
                try:
                    from_idx = [p.upper() for p in parts].index('FROM')
                    if from_idx + 1 < len(parts):
                        table_name = parts[from_idx + 1].split()[0].strip()
                        return table_name
                except (ValueError, IndexError):
                    pass
        
        elif self.operation_type == OperationType.MERGE:
            # MERGE INTO table_name ...
            if 'INTO' in query_upper:
                parts = self.query.split()
                try:
                    into_idx = [p.upper() for p in parts].index('INTO')
                    if into_idx + 1 < len(parts):
                        table_name = parts[into_idx + 1].split()[0].strip()
                        return table_name
                except (ValueError, IndexError):
                    pass
        
        return None


class DataFile:
    """
    Represents local CSV/JSON file for bulk operations.
    
    Implements data-model.md DataFile entity (placeholder for Phase 6).
    """
    
    def __init__(
        self,
        path: str,
        format: str = "csv",
        delimiter: str = ",",
        has_header: bool = True
    ):
        """Initialize DataFile (to be implemented in Phase 6 - US4 Bulk Operations)."""
        self.path = path
        self.format = format
        self.delimiter = delimiter
        self.has_header = has_header
