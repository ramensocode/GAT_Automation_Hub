"""
Data validation for Snowflake operations.
Implements FR-017: Basic data validation (type compatibility, NOT NULL).
"""

from typing import Any, Dict, List, Optional, Tuple
from datetime import date, datetime
import logging
from decimal import Decimal

from .logging import configure_logging


class ValidationError(Exception):
    """Raised when data validation fails."""
    pass


class SnowflakeValidator:
    """
    Validates data before write operations to Snowflake.
    
    Implements FR-017: Pre-flight validation for type compatibility and NOT NULL
    constraints. Snowflake handles complex constraint enforcement.
    """
    
    # Snowflake to Python type mapping per FR-006 and data-model.md
    TYPE_MAPPING = {
        'VARCHAR': str,
        'CHAR': str,
        'CHARACTER': str,
        'STRING': str,
        'TEXT': str,
        'NUMBER': (int, float, Decimal),
        'DECIMAL': (int, float, Decimal),
        'NUMERIC': (int, float, Decimal),
        'INT': int,
        'INTEGER': int,
        'BIGINT': int,
        'SMALLINT': int,
        'TINYINT': int,
        'BYTEINT': int,
        'FLOAT': float,
        'FLOAT4': float,
        'FLOAT8': float,
        'DOUBLE': float,
        'DOUBLE PRECISION': float,
        'REAL': float,
        'BOOLEAN': bool,
        'DATE': date,
        'DATETIME': datetime,
        'TIME': datetime,
        'TIMESTAMP': datetime,
        'TIMESTAMP_LTZ': datetime,
        'TIMESTAMP_NTZ': datetime,
        'TIMESTAMP_TZ': datetime,
        'VARIANT': (dict, list, str, int, float, bool, type(None)),
        'OBJECT': dict,
        'ARRAY': list,
        'BINARY': bytes,
        'VARBINARY': bytes,
    }
    
    def __init__(self, log_level: str = "INFO"):
        """
        Initialize validator.
        
        Args:
            log_level: Logging level
        """
        self._logger = configure_logging(log_level)
        self._schema_cache: Dict[str, List[Dict[str, Any]]] = {}
    
    def parse_snowflake_type(self, type_string: str) -> str:
        """
        Parse Snowflake type string to base type.
        
        Examples:
            VARCHAR(255) -> VARCHAR
            NUMBER(38,0) -> NUMBER
            TIMESTAMP_NTZ(9) -> TIMESTAMP_NTZ
        
        Args:
            type_string: Snowflake type definition
        
        Returns:
            Base type name
        """
        # Remove precision/scale information
        base_type = type_string.split('(')[0].strip().upper()
        return base_type
    
    def validate_type_compatibility(
        self,
        value: Any,
        snowflake_type: str,
        column_name: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate that Python value is compatible with Snowflake type.
        
        Args:
            value: Python value to validate
            snowflake_type: Snowflake column type
            column_name: Column name (for error messages)
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if value is None:
            # NULL values handled by NOT NULL check
            return True, None
        
        base_type = self.parse_snowflake_type(snowflake_type)
        
        if base_type not in self.TYPE_MAPPING:
            # Unknown type - let Snowflake handle it
            self._logger.warning(
                f"Unknown Snowflake type '{base_type}' for column '{column_name}', "
                "skipping type validation"
            )
            return True, None
        
        expected_types = self.TYPE_MAPPING[base_type]
        if not isinstance(expected_types, tuple):
            expected_types = (expected_types,)
        
        if not isinstance(value, expected_types):
            actual_type = type(value).__name__
            expected_names = ', '.join(t.__name__ for t in expected_types)
            error_msg = (
                f"Type mismatch for column '{column_name}': "
                f"expected {expected_names} (Snowflake type: {snowflake_type}), "
                f"got {actual_type}"
            )
            return False, error_msg
        
        return True, None
    
    def validate_not_null(
        self,
        value: Any,
        nullable: bool,
        column_name: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate NOT NULL constraint.
        
        Args:
            value: Value to validate
            nullable: Whether column allows NULL
            column_name: Column name (for error messages)
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if value is None and not nullable:
            error_msg = f"NULL value for NOT NULL column: '{column_name}'"
            return False, error_msg
        
        return True, None
    
    def validate_row(
        self,
        row: Dict[str, Any],
        schema: List[Dict[str, Any]]
    ) -> List[str]:
        """
        Validate a single data row against schema.
        
        Args:
            row: Dictionary mapping column names to values
            schema: List of column metadata dicts with keys:
                    'name', 'type', 'nullable'
        
        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []
        
        for column in schema:
            col_name = column['name']
            col_type = column['type']
            col_nullable = column.get('nullable', True)
            
            # Get value from row
            value = row.get(col_name)
            
            # Validate NOT NULL
            is_valid, error = self.validate_not_null(value, col_nullable, col_name)
            if not is_valid:
                errors.append(error)
                continue  # Skip type check if NULL violation
            
            # Validate type compatibility
            is_valid, error = self.validate_type_compatibility(value, col_type, col_name)
            if not is_valid:
                errors.append(error)
        
        return errors
    
    def validate_rows(
        self,
        rows: List[Dict[str, Any]],
        schema: List[Dict[str, Any]],
        fail_fast: bool = False
    ) -> Dict[str, Any]:
        """
        Validate multiple data rows against schema.
        
        Args:
            rows: List of row dictionaries
            schema: List of column metadata dicts
            fail_fast: Stop on first error (default: False)
        
        Returns:
            Dictionary with validation results:
            {
                'valid': bool,
                'total_rows': int,
                'valid_rows': int,
                'invalid_rows': int,
                'errors': List[Dict] with 'row_number' and 'errors'
            }
        """
        result = {
            'valid': True,
            'total_rows': len(rows),
            'valid_rows': 0,
            'invalid_rows': 0,
            'errors': []
        }
        
        for row_num, row in enumerate(rows, start=1):
            row_errors = self.validate_row(row, schema)
            
            if row_errors:
                result['valid'] = False
                result['invalid_rows'] += 1
                result['errors'].append({
                    'row_number': row_num,
                    'errors': row_errors
                })
                
                if fail_fast:
                    break
            else:
                result['valid_rows'] += 1
        
        return result
    
    def fetch_table_schema(
        self,
        cursor,
        table_name: str,
        schema_name: str = "PUBLIC",
        use_fully_qualified: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Fetch table schema metadata from Snowflake using DESCRIBE TABLE.
        
        Implements data validation strategy from plan.md R5.
        
        Args:
            cursor: Snowflake database cursor
            table_name: Table name (can be fully qualified: database.schema.table)
            schema_name: Schema name (default: PUBLIC) - ignored if use_fully_qualified=True
            use_fully_qualified: If True, use table_name as-is (supports fully qualified names)
        
        Returns:
            List of column metadata dictionaries with keys:
            - name: Column name
            - type: Snowflake data type
            - nullable: Whether column allows NULL
            - default: Default value (if any)
        """
        # If table name is already fully qualified or use_fully_qualified flag is set,
        # use it as-is. Otherwise prepend schema_name.
        if use_fully_qualified or '.' in table_name:
            # Use as-is (fully qualified or schema-qualified)
            full_table_name = table_name
            cache_key = table_name
        else:
            # Prepend schema name
            full_table_name = f"{schema_name}.{table_name}"
            cache_key = full_table_name
        
        # Check cache
        if cache_key in self._schema_cache:
            self._logger.debug(f"Using cached schema for {cache_key}")
            return self._schema_cache[cache_key]
        
        # Fetch schema from Snowflake
        try:
            query = f"DESCRIBE TABLE {full_table_name}"
            cursor.execute(query)
            rows = cursor.fetchall()
            
            schema = []
            for row in rows:
                # DESCRIBE TABLE returns: name, type, kind, null?, default, primary key, unique key, check, expression, comment, policy name
                schema.append({
                    'name': row[0] if isinstance(row, tuple) else row.get('name'),
                    'type': row[1] if isinstance(row, tuple) else row.get('type'),
                    'nullable': (row[3] if isinstance(row, tuple) else row.get('null?')) == 'Y',
                    'default': row[4] if isinstance(row, tuple) else row.get('default'),
                })
            
            # Cache schema
            self._schema_cache[cache_key] = schema
            self._logger.debug(f"Cached schema for {cache_key} ({len(schema)} columns)")
            
            return schema
            
        except Exception as e:
            self._logger.error(f"Failed to fetch schema for {cache_key}: {e}")
            raise ValidationError(f"Cannot fetch table schema: {e}")
    
    def clear_cache(self) -> None:
        """Clear schema metadata cache."""
        self._schema_cache.clear()
        self._logger.debug("Cleared schema cache")
