"""
Snowflake module utilities for Ansible
Feature: 001-ansible-snowflake-automation

Provides connection management, query execution, and data validation
for Snowflake data warehouse operations.
"""

__version__ = "1.0.0"

from .connection import SnowflakeConnection
from .validation import SnowflakeValidator
from .logging import configure_logging, mask_sensitive_data, log_error
from .parameters import validate_parameters, detect_sql_injection_risk, extract_parameter_names

__all__ = [
    "SnowflakeConnection",
    "SnowflakeValidator",
    "configure_logging",
    "mask_sensitive_data",
    "log_error",
    "validate_parameters",
    "detect_sql_injection_risk",
    "extract_parameter_names",
]

# Import query module if available (Phase 3+)
try:
    from .query import QueryTask, ResultSet
    __all__.extend(["QueryTask", "ResultSet"])
except ImportError:
    pass
