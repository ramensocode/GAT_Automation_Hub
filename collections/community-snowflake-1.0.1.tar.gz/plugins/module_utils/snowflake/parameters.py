"""
Parameter validation utilities for SQL injection prevention.
Feature: 001-ansible-snowflake-automation
Phase 5: US3 Parameterization
"""

import re
from typing import Dict, Any, List, Set


def extract_parameter_names(query: str) -> Set[str]:
    """
    Extract all bind variable names from a SQL query.
    
    Args:
        query: SQL query string
    
    Returns:
        Set of parameter names found in the query
    """
    # Match :parameter_name pattern (Snowflake bind variables)
    pattern = r':([a-zA-Z_][a-zA-Z0-9_]*)'
    return set(re.findall(pattern, query))


def validate_parameters(parameters: Dict[str, Any], query: str = None) -> None:
    """
    Validate parameters for SQL injection prevention (FR-005).
    
    Ensures parameters are JSON-serializable and safe for use in queries.
    If query is provided, validates that all required parameters are supplied.
    
    Args:
        parameters: Dictionary of parameter name/value pairs
        query: Optional SQL query to check for missing parameters
    
    Raises:
        ValueError: If parameters contain unsafe types or values, or if required parameters are missing
    """
    if not parameters:
        parameters = {}
    
    # If query provided, check for missing parameters
    if query:
        required_params = extract_parameter_names(query)
        provided_params = set(parameters.keys())
        missing_params = required_params - provided_params
        
        if missing_params:
            raise ValueError(
                f"Missing required parameters: {', '.join(sorted(missing_params))}. "
                f"Query expects: {', '.join(sorted(required_params))}"
            )
    
    # Allowed types for parameters (JSON-serializable)
    SAFE_TYPES = (str, int, float, bool, type(None), list, dict)
    
    for param_name, param_value in parameters.items():
        # Validate parameter name (alphanumeric + underscore only)
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', param_name):
            raise ValueError(
                f"Invalid parameter name '{param_name}'. "
                "Use alphanumeric characters and underscores only."
            )
        
        # Validate parameter value type
        if param_value is not None and not isinstance(param_value, SAFE_TYPES):
            raise ValueError(
                f"Parameter '{param_name}' has unsupported type {type(param_value).__name__}. "
                f"Use JSON-serializable types: str, int, float, bool, list, dict, or None."
            )
        
        # Recursive validation for list/dict values
        if isinstance(param_value, list):
            for item in param_value:
                if item is not None and not isinstance(item, SAFE_TYPES):
                    raise ValueError(
                        f"Parameter '{param_name}' list contains unsupported type {type(item).__name__}"
                    )
        
        elif isinstance(param_value, dict):
            validate_parameters(param_value)  # Recursive validation


def detect_sql_injection_risk(query: str, parameters: Dict[str, Any]) -> List[str]:
    """
    Detect potential SQL injection risks in query (FR-005).
    
    Checks for string concatenation patterns that should use parameters instead.
    
    Args:
        query: SQL query text
        parameters: Parameter dictionary
    
    Returns:
        List of warning messages (empty if no risks detected)
    """
    warnings = []
    
    # Pattern 1: String concatenation with + operator
    if re.search(r'["\'].*\+.*["\']', query):
        warnings.append(
            "Query contains string concatenation (+). "
            "Use parameter binding (:param_name) instead to prevent SQL injection."
        )
    
    # Pattern 2: Python f-string or format() patterns
    if '{' in query and '}' in query:
        warnings.append(
            "Query contains {{ }} braces. "
            "If using string formatting, switch to parameter binding (:param_name) for safety."
        )
    
    # Pattern 3: Python % formatting
    if re.search(r'%\([a-zA-Z_]+\)s', query):
        warnings.append(
            "Query contains Python % formatting. "
            "Use parameter binding (:param_name) instead to prevent SQL injection."
        )
    
    # Pattern 4: WHERE clause without parameters
    if 'WHERE' in query.upper():
        # Check if WHERE clause uses parameter binding
        where_match = re.search(r'WHERE\s+(.+?)(?:ORDER|GROUP|LIMIT|;|$)', query, re.IGNORECASE | re.DOTALL)
        if where_match:
            where_clause = where_match.group(1)
            # Check for hardcoded values (quoted strings or numbers) without parameters
            if re.search(r'[=<>]\s*["\'][^"\']+["\']', where_clause) and not parameters:
                warnings.append(
                    "WHERE clause uses hardcoded values. "
                    "Consider using parameter binding (:param_name) for reusable queries."
                )
    
    return warnings


def convert_to_snowflake_format(query: str) -> str:
    """
    Convert parameter placeholders to Snowflake Python connector format.
    
    Snowflake Python connector expects %(param_name)s format for dict parameters.
    This function converts :param_name to %(param_name)s.
    
    Args:
        query: SQL query text with parameter placeholders
    
    Returns:
        Query with %(param_name)s format for dict parameters
    """
    # Convert :param_name to %(param_name)s (Snowflake Python connector format for dicts)
    query = re.sub(r':([a-zA-Z_][a-zA-Z0-9_]*)', r'%(\1)s', query)
    
    return query
