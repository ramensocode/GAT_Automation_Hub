"""
Logging utilities with credential masking for Snowflake operations.
Implements FR-008: structured logging without exposing sensitive data.
"""

import re
import logging
from typing import Dict, Any


def configure_logging(level: str = "INFO") -> logging.Logger:
    """
    Configure structured logging for Snowflake module.
    
    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)
    
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger("ansible_snowflake")
    logger.setLevel(getattr(logging, level.upper()))
    
    # Avoid duplicate handlers
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(levelname)s: [Snowflake] %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    return logger


def mask_sensitive_data(text: str) -> str:
    """
    Mask sensitive information in log messages and connection strings.
    
    Masks:
    - Passwords in connection strings
    - Authorization tokens
    - API keys
    
    Args:
        text: Text potentially containing sensitive data
    
    Returns:
        Text with sensitive data masked as '***REDACTED***'
    """
    if not text:
        return text
    
    # Mask password in connection strings
    # Pattern: password='...' or password=...
    text = re.sub(
        r"password=['\"]?[^'\";\s]+['\"]?",
        "password=***REDACTED***",
        text,
        flags=re.IGNORECASE
    )
    
    # Mask password in key-value pairs
    text = re.sub(
        r"(['\"]password['\"]:\s*['\"])[^'\"]+(['\"])",
        r"\1***REDACTED***\2",
        text,
        flags=re.IGNORECASE
    )
    
    # Mask authorization headers
    text = re.sub(
        r"(Authorization:\s*Bearer\s+)[^\s]+",
        r"\1***REDACTED***",
        text,
        flags=re.IGNORECASE
    )
    
    # Mask API keys
    text = re.sub(
        r"(api[_-]?key['\"]?:\s*['\"]?)[^'\";\s]+",
        r"\1***REDACTED***",
        text,
        flags=re.IGNORECASE
    )
    
    return text


def log_connection_attempt(logger: logging.Logger, account: str, user: str, 
                          warehouse: str = None, database: str = None) -> None:
    """
    Log connection attempt with masked credentials.
    
    Args:
        logger: Logger instance
        account: Snowflake account identifier
        user: Username (safe to log)
        warehouse: Warehouse name (optional)
        database: Database name (optional)
    """
    msg = f"Connecting to Snowflake account={account}, user={user}"
    if warehouse:
        msg += f", warehouse={warehouse}"
    if database:
        msg += f", database={database}"
    logger.info(msg)


def log_query_execution(logger: logging.Logger, query_id: str = None, 
                       execution_time_ms: int = None, row_count: int = None,
                       operation: str = "query") -> None:
    """
    Log query execution metrics.
    
    Args:
        logger: Logger instance
        query_id: Snowflake query ID
        execution_time_ms: Execution time in milliseconds
        row_count: Number of rows affected/returned
        operation: Operation type (SELECT, INSERT, etc.)
    """
    msg = f"{operation.upper()} completed"
    if query_id:
        msg += f", query_id={query_id}"
    if row_count is not None:
        msg += f", rows={row_count}"
    if execution_time_ms is not None:
        msg += f", execution_time_ms={execution_time_ms}"
    logger.info(msg)


def log_retry_attempt(logger: logging.Logger, attempt: int, max_attempts: int,
                     error: str) -> None:
    """
    Log retry attempts for transient errors.
    
    Args:
        logger: Logger instance
        attempt: Current retry attempt number
        max_attempts: Maximum retry attempts
        error: Error message (will be masked)
    """
    masked_error = mask_sensitive_data(str(error))
    logger.warning(
        f"Retry attempt {attempt}/{max_attempts} due to transient error: {masked_error}"
    )


def log_error(logger: logging.Logger, error_type: str, error_message: str,
             context: Dict[str, Any] = None) -> None:
    """
    Log error with context and masked sensitive data.
    
    Args:
        logger: Logger instance
        error_type: Error category (auth, syntax, network, validation)
        error_message: Error message
        context: Additional context (will be masked)
    """
    masked_message = mask_sensitive_data(error_message)
    msg = f"{error_type.upper()} ERROR: {masked_message}"
    
    if context:
        # Mask sensitive data in context values
        masked_context = {}
        for k, v in context.items():
            # Convert to string and mask
            str_value = str(v)
            masked_value = mask_sensitive_data(str_value)
            # If the key itself suggests sensitive data, mask regardless
            if k.lower() in ['password', 'token', 'api_key', 'secret']:
                masked_value = '***REDACTED***'
            masked_context[k] = masked_value
        msg += f" | Context: {masked_context}"
    
    logger.error(msg)
