"""
Snowflake connection management with retry logic.
Implements FR-010 (connection validation), FR-016 (retry logic).
"""

import logging
from typing import Optional, Dict, Any
from contextlib import contextmanager
import snowflake.connector
from snowflake.connector import DictCursor
from snowflake.connector.errors import (
    Error as SnowflakeError,
    DatabaseError,
    OperationalError,
    ProgrammingError
)
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log
)

from .logging import configure_logging, log_connection_attempt, log_retry_attempt


class SnowflakeConnection:
    """
    Manages Snowflake database connections with automatic retry logic.
    
    Implements data-model.md SnowflakeConnection entity with:
    - Connection pooling (single connection per execution)
    - Retry logic with exponential backoff (1s, 2s, 4s)
    - Connection validation before query execution
    - Credential masking in logs
    """
    
    def __init__(
        self,
        account: str,
        user: str,
        password: str,
        warehouse: Optional[str] = None,
        database: Optional[str] = None,
        schema: Optional[str] = "PUBLIC",
        role: Optional[str] = None,
        timeout: int = 30,
        connection_timeout: int = 10,
        retry_attempts: int = 3,
        backoff_multiplier: int = 1,
        log_level: str = "INFO"
    ):
        """
        Initialize Snowflake connection parameters.
        
        Args:
            account: Snowflake account identifier (e.g., "abc123.us-east-1")
            user: Username for authentication
            password: Password for authentication (will be masked in logs)
            warehouse: Compute warehouse name
            database: Target database name
            schema: Target schema name (default: PUBLIC)
            role: Snowflake role for session
            timeout: Query timeout in seconds (default: 30)
            connection_timeout: Connection timeout in seconds (default: 10)
            retry_attempts: Number of retry attempts (default: 3)
            backoff_multiplier: Exponential backoff multiplier (default: 1)
            log_level: Logging level (default: INFO)
        """
        # Validation per data-model.md
        if not account:
            raise ValueError("account must not be empty")
        if not user:
            raise ValueError("user must not be empty")
        if not password:
            raise ValueError("password must not be empty")
        if timeout <= 0 or timeout > 3600:
            raise ValueError("timeout must be > 0 and <= 3600 seconds")
        if connection_timeout <= 0 or connection_timeout > 300:
            raise ValueError("connection_timeout must be > 0 and <= 300 seconds")
        
        self.account = account
        self.user = user
        self.password = password
        self.warehouse = warehouse
        self.database = database
        self.schema = schema
        self.role = role
        self.timeout = timeout
        self.connection_timeout = connection_timeout
        self.retry_attempts = retry_attempts
        self.backoff_multiplier = backoff_multiplier
        
        self._connection = None
        self._logger = configure_logging(log_level)
    
    def _is_transient_error(self, exception: Exception) -> bool:
        """
        Determine if an error is transient and should be retried.
        
        Per plan.md R3 research decision:
        - Transient: Network errors, timeouts, rate limits
        - Permanent: Authentication failures, SQL syntax errors, permission denied
        
        Args:
            exception: Exception to evaluate
        
        Returns:
            True if error is transient, False if permanent
        """
        error_msg = str(exception).lower()
        
        # Permanent errors (do not retry)
        permanent_patterns = [
            'authentication',
            'invalid username',
            'invalid password',
            'incorrect username or password',
            'permission denied',
            'syntax error',
            'does not exist',
            'already exists',
        ]
        
        for pattern in permanent_patterns:
            if pattern in error_msg:
                return False
        
        # Transient errors (retry)
        if isinstance(exception, OperationalError):
            # Network/connection errors
            return True
        
        if isinstance(exception, ProgrammingError):
            # Check for timeout specifically
            if 'timeout' in error_msg or 'timed out' in error_msg:
                return True
            # Other programming errors are permanent
            return False
        
        # Default: don't retry unknown errors
        return False
    
    def _create_retry_decorator(self):
        """
        Create retry decorator with exponential backoff.
        
        Implements FR-016: 3 attempts with 1s, 2s, 4s backoff
        """
        return retry(
            stop=stop_after_attempt(self.retry_attempts),
            wait=wait_exponential(
                multiplier=self.backoff_multiplier,
                min=1,
                max=4
            ),
            retry=retry_if_exception_type(OperationalError),
            before_sleep=before_sleep_log(self._logger, logging.WARNING),
            reraise=True
        )
    
    @property
    def is_connected(self) -> bool:
        """Check if connection is active."""
        return self._connection is not None and not self._connection.is_closed()
    
    def connect(self) -> None:
        """
        Establish connection to Snowflake with retry logic.
        
        Implements FR-010: Connection validation before query execution
        Implements FR-016: Retry logic with exponential backoff
        
        Raises:
            DatabaseError: Authentication or permission errors
            OperationalError: Network or connection errors (after retries)
        """
        if self.is_connected:
            return
        
        log_connection_attempt(
            self._logger,
            self.account,
            self.user,
            self.warehouse,
            self.database
        )
        
        @self._create_retry_decorator()
        def _connect_with_retry():
            try:
                self._connection = snowflake.connector.connect(
                    account=self.account,
                    user=self.user,
                    password=self.password,
                    warehouse=self.warehouse,
                    database=self.database,
                    schema=self.schema,
                    role=self.role,
                    login_timeout=self.connection_timeout,
                    network_timeout=self.timeout
                )
                self._logger.info(f"Successfully connected to Snowflake account={self.account}")
            except (DatabaseError, OperationalError) as e:
                if self._is_transient_error(e):
                    self._logger.warning(f"Transient connection error, will retry: {type(e).__name__}")
                    raise
                else:
                    self._logger.error(f"Permanent connection error: {type(e).__name__}")
                    raise
        
        _connect_with_retry()
    
    def validate_connection(self) -> bool:
        """
        Validate that connection is active and healthy.
        
        Implements FR-010: Connection validation
        
        Returns:
            True if connection is valid
        
        Raises:
            OperationalError: If connection validation fails
        """
        if not self.is_connected:
            raise OperationalError("Connection not established")
        
        try:
            # Simple query to verify connection
            cursor = self._connection.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
            self._logger.debug("Connection validation successful")
            return True
        except Exception as e:
            self._logger.error(f"Connection validation failed: {e}")
            raise OperationalError(f"Connection validation failed: {e}")
    
    @contextmanager
    def cursor(self, dictionary: bool = True):
        """
        Context manager for database cursor.
        
        Args:
            dictionary: Return results as dictionaries (default: True)
        
        Yields:
            Database cursor
        
        Raises:
            OperationalError: If connection is not established
        """
        if not self.is_connected:
            raise OperationalError("Connection not established. Call connect() first.")
        
        cursor = self._connection.cursor(DictCursor if dictionary else None)
        try:
            yield cursor
        finally:
            cursor.close()
    
    def close(self) -> None:
        """
        Close Snowflake connection.
        """
        if self._connection and not self._connection.is_closed():
            self._connection.close()
            self._logger.info("Closed Snowflake connection")
            self._connection = None
    
    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False
