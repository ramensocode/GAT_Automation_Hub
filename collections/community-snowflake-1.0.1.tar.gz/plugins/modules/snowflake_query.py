#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2026, Data Engineering Team
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function
__metaclass__ = type

DOCUMENTATION = r'''
---
module: snowflake_query
short_description: Execute SQL queries against Snowflake data warehouse
version_added: "1.0.0"
description:
  - Execute SELECT, INSERT, UPDATE, DELETE, and MERGE operations on Snowflake tables
  - Automatic retry logic with exponential backoff for transient errors
  - Data validation before write operations
  - Secure credential handling with Ansible vault integration
  - Structured logging without credential exposure
requirements:
  - python >= 3.9
  - snowflake-connector-python >= 3.0.0
  - tenacity >= 8.0.0
author:
  - Data Engineering Team
options:
  snowflake_account:
    description:
      - Snowflake account identifier (e.g., "abc123.us-east-1")
    required: true
    type: str
  snowflake_user:
    description:
      - Username for Snowflake authentication
    required: true
    type: str
  snowflake_password:
    description:
      - Password for Snowflake authentication
      - Use Ansible vault to encrypt this value
    required: true
    type: str
    no_log: true
  snowflake_warehouse:
    description:
      - Compute warehouse name for query execution
    required: false
    type: str
  snowflake_database:
    description:
      - Target database name
    required: false
    type: str
  snowflake_schema:
    description:
      - Target schema name within database
    required: false
    type: str
    default: PUBLIC
  snowflake_role:
    description:
      - Snowflake role for session permissions
    required: false
    type: str
  operation:
    description:
      - SQL operation type to execute
      - Auto-detected from query if not specified
    required: false
    type: str
    choices: ['select', 'insert', 'update', 'delete', 'merge', 'execute']
  transaction_mode:
    description:
      - Transaction handling mode
      - auto commits on success, rollback on error
      - manual requires explicit COMMIT/ROLLBACK in query
    required: false
    type: str
    choices: ['auto', 'manual']
    default: auto
  query:
    description:
      - SQL query text to execute
      - Mutually exclusive with query_file
    required: false
    type: str
  query_file:
    description:
      - Path to file containing SQL query
      - Mutually exclusive with query
    required: false
    type: path
  parameters:
    description:
      - Named parameters for query parameterization
      - Prevents SQL injection
    required: false
    type: dict
    default: {}
  timeout:
    description:
      - Query timeout in seconds
    required: false
    type: int
    default: 30
  output_format:
    description:
      - Format for query results
    required: false
    type: str
    choices: ['json', 'csv', 'yaml']
    default: json
  output_file:
    description:
      - Path to write query results
      - Automatically used for large result sets (>10K rows)
    required: false
    type: path
'''

EXAMPLES = r'''
# Execute SELECT query with vault credentials
- name: Query Snowflake customers table
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_warehouse: "COMPUTE_WH"
    snowflake_database: "PROD_DB"
    snowflake_schema: "PUBLIC"
    query: "SELECT * FROM customers WHERE region = 'US-WEST'"
    output_format: json
  register: result

- debug:
    msg: "Retrieved {{ result.row_count }} rows in {{ result.execution_time_ms }}ms"

# Execute INSERT operation with automatic transaction
- name: Insert customer record
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_database: "PROD_DB"
    query: "INSERT INTO customers (id, name, email) VALUES (1, 'John Doe', 'john@example.com')"
    transaction_mode: auto
  register: insert_result

- debug:
    msg: "Inserted {{ insert_result.row_count }} rows"
  when: insert_result.changed

# Execute UPDATE operation
- name: Update customer email
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_database: "PROD_DB"
    query: "UPDATE customers SET email = 'newemail@example.com' WHERE id = 1"

# Execute MERGE (upsert) operation
- name: Upsert customer data
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_database: "PROD_DB"
    query: |
      MERGE INTO customers AS target
      USING (SELECT 1 AS id, 'Jane Doe' AS name, 'jane@example.com' AS email) AS source
      ON target.id = source.id
      WHEN MATCHED THEN UPDATE SET name = source.name, email = source.email
      WHEN NOT MATCHED THEN INSERT (id, name, email) VALUES (source.id, source.name, source.email)

# Query from file with output to CSV
- name: Run complex query from file
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_database: "ANALYTICS_DB"
    query_file: "/path/to/query.sql"
    output_format: csv
    output_file: "/tmp/results.csv"
'''

RETURN = r'''
changed:
  description: Whether the operation modified data
  returned: always
  type: bool
  sample: true
row_count:
  description: Number of rows affected or returned
  returned: always
  type: int
  sample: 1534
execution_time_ms:
  description: Query execution duration in milliseconds
  returned: always
  type: int
  sample: 2456
query_id:
  description: Snowflake query ID for debugging
  returned: always
  type: str
  sample: "01a2b3c4-5678-90de-f012-3456789abcde"
rows:
  description: Query result rows (for SELECT operations)
  returned: when query is SELECT and result fits in memory
  type: list
  elements: dict
  sample: [{"id": 1, "name": "John", "email": "john@example.com"}]
column_metadata:
  description: Schema information for result columns
  returned: when query is SELECT
  type: list
  elements: dict
  sample: [{"name": "id", "type": "int", "nullable": true}]
warnings:
  description: Non-fatal warnings from query execution
  returned: when warnings exist
  type: list
  elements: str
  sample: ["Type coercion applied to column 'amount'"]
'''

import sys
import os
import traceback

from ansible.module_utils.basic import AnsibleModule

try:
    # Try collection-style import first (for installed collections)
    from ansible_collections.community.snowflake.plugins.module_utils.snowflake import (
        SnowflakeConnection,
        QueryTask,
        configure_logging,
        log_error
    )
    HAS_SNOWFLAKE_UTILS = True
    IMPORT_ERROR = None
except ImportError:
    try:
        # Fallback to ansible.module_utils namespace (Ansible resolves for collections)
        from ansible.module_utils.snowflake import (
            SnowflakeConnection,
            QueryTask,
            configure_logging,
            log_error
        )
        HAS_SNOWFLAKE_UTILS = True
        IMPORT_ERROR = None
    except ImportError as e:
        HAS_SNOWFLAKE_UTILS = False
        IMPORT_ERROR = str(e)


def read_query_file(filepath):
    """Read SQL query from file."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except IOError as e:
        raise Exception(f"Failed to read query file {filepath}: {e}")


def read_csv_file(filepath, delimiter=',', has_header=True):
    """Read data from CSV file for bulk operations."""
    import csv
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            if has_header:
                reader = csv.DictReader(f, delimiter=delimiter)
                return list(reader)
            else:
                reader = csv.reader(f, delimiter=delimiter)
                rows = list(reader)
                # If no header, create generic column names
                if rows:
                    num_cols = len(rows[0])
                    headers = [f'col_{i}' for i in range(num_cols)]
                    return [dict(zip(headers, row)) for row in rows]
                return []
    except IOError as e:
        raise Exception(f"Failed to read CSV file {filepath}: {e}")
    except csv.Error as e:
        raise Exception(f"Failed to parse CSV file {filepath}: {e}")


def read_json_file(filepath):
    """Read data from JSON file for bulk operations."""
    import json
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            # Ensure data is a list of dictionaries
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                return [data]
            else:
                raise Exception("JSON file must contain an array or object")
    except IOError as e:
        raise Exception(f"Failed to read JSON file {filepath}: {e}")
    except json.JSONDecodeError as e:
        raise Exception(f"Failed to parse JSON file {filepath}: {e}")


def main():
    """Main module execution."""
    
    # Define module argument specification
    module_args = dict(
        # Connection parameters
        snowflake_account=dict(type='str', required=True),
        snowflake_user=dict(type='str', required=True),
        snowflake_password=dict(type='str', required=True, no_log=True),
        snowflake_warehouse=dict(type='str', required=False),
        snowflake_database=dict(type='str', required=False),
        snowflake_schema=dict(type='str', required=False, default='PUBLIC'),
        snowflake_role=dict(type='str', required=False),
        
        # Operation parameters
        operation=dict(
            type='str',
            required=False,
            choices=['select', 'insert', 'update', 'delete', 'merge', 'execute']
        ),
        transaction_mode=dict(
            type='str',
            required=False,
            default='auto',
            choices=['auto', 'manual']
        ),
        
        # Query parameters
        query=dict(type='str', required=False),
        query_file=dict(type='path', required=False),
        parameters=dict(type='dict', required=False, default={}),
        timeout=dict(type='int', required=False, default=30),
        
        # Output parameters
        output_format=dict(
            type='str',
            required=False,
            default='json',
            choices=['json', 'csv', 'yaml']
        ),
        output_file=dict(type='path', required=False),
        
        # Bulk operation parameters
        input_file=dict(type='path', required=False),
        input_format=dict(
            type='str',
            required=False,
            choices=['csv', 'json']
        ),
        csv_delimiter=dict(type='str', required=False, default=','),
        csv_has_header=dict(type='bool', required=False, default=True),
    )
    
    # Define mutually exclusive parameters
    mutually_exclusive = [
        ['query', 'query_file']
    ]
    
    # Define required one of
    required_one_of = [
        ['query', 'query_file']
    ]
    
    # Initialize module
    module = AnsibleModule(
        argument_spec=module_args,
        mutually_exclusive=mutually_exclusive,
        required_one_of=required_one_of,
        supports_check_mode=False  # Will implement in Phase 7
    )
    
    # Check for required imports
    if not HAS_SNOWFLAKE_UTILS:
        module.fail_json(
            msg=f"Failed to import Snowflake utilities: {IMPORT_ERROR}",
            exception=traceback.format_exc()
        )
    
    # Configure logging
    logger = configure_logging("INFO")
    
    try:
        # Get query text
        query_text = module.params.get('query')
        query_file = module.params.get('query_file')
        
        if query_file:
            query_text = read_query_file(query_file)
        
        if not query_text:
            module.fail_json(msg="Query text is empty")
        
        # Create connection
        connection = SnowflakeConnection(
            account=module.params['snowflake_account'],
            user=module.params['snowflake_user'],
            password=module.params['snowflake_password'],
            warehouse=module.params.get('snowflake_warehouse'),
            database=module.params.get('snowflake_database'),
            schema=module.params.get('snowflake_schema'),
            role=module.params.get('snowflake_role'),
            timeout=module.params['timeout'],
            log_level="INFO"
        )
        
        # Connect to Snowflake
        connection.connect()
        
        # Validate connection (FR-010)
        connection.validate_connection()
        
        # Check if this is a bulk operation with input file
        input_file = module.params.get('input_file')
        
        if input_file:
            # Bulk operation mode
            input_format = module.params.get('input_format')
            
            # Auto-detect format from file extension if not specified
            if not input_format:
                if input_file.lower().endswith('.csv'):
                    input_format = 'csv'
                elif input_file.lower().endswith('.json'):
                    input_format = 'json'
                else:
                    module.fail_json(msg=f"Cannot detect input format from file extension: {input_file}")
            
            # Read data from file
            try:
                if input_format == 'csv':
                    csv_delimiter = module.params.get('csv_delimiter', ',')
                    csv_has_header = module.params.get('csv_has_header', True)
                    bulk_data = read_csv_file(input_file, csv_delimiter, csv_has_header)
                elif input_format == 'json':
                    bulk_data = read_json_file(input_file)
                else:
                    module.fail_json(msg=f"Unsupported input format: {input_format}")
            except Exception as e:
                module.fail_json(msg=f"Failed to read input file: {e}")
            
            if not bulk_data:
                module.fail_json(msg=f"No data found in input file: {input_file}")
            
            # Execute bulk inserts
            total_rows = 0
            total_time_ms = 0
            failed_rows = []
            
            for idx, row_data in enumerate(bulk_data, start=1):
                try:
                    # Create query task with row data as parameters
                    task = QueryTask(
                        query=query_text,
                        parameters=row_data,
                        output_format=module.params['output_format'],
                        output_file=None,  # No output for bulk inserts
                        timeout=module.params['timeout'],
                        log_level="INFO",
                        operation=module.params.get('operation'),
                        transaction_mode=module.params.get('transaction_mode', 'auto'),
                        validate_data=True
                    )
                    
                    result = task.execute(connection)
                    total_rows += result.row_count
                    total_time_ms += result.execution_time_ms
                    
                except Exception as e:
                    failed_rows.append({
                        'row_number': idx,
                        'data': row_data,
                        'error': str(e)
                    })
            
            # Close connection
            connection.close()
            
            # Return results
            if failed_rows:
                module.fail_json(
                    msg=f"Bulk operation partially failed: {len(failed_rows)}/{len(bulk_data)} rows failed",
                    row_count=total_rows,
                    execution_time_ms=total_time_ms,
                    changed=total_rows > 0,
                    failed_rows=failed_rows,
                    total_attempted=len(bulk_data)
                )
            else:
                module.exit_json(
                    changed=True,
                    row_count=total_rows,
                    execution_time_ms=total_time_ms,
                    msg=f"Successfully processed {total_rows} rows from {input_file}"
                )
        
        else:
            # Single query execution (existing logic)
            task = QueryTask(
                query=query_text,
                parameters=module.params.get('parameters', {}),
                output_format=module.params['output_format'],
                output_file=module.params.get('output_file'),
                timeout=module.params['timeout'],
                log_level="INFO",
                operation=module.params.get('operation'),
                transaction_mode=module.params.get('transaction_mode', 'auto'),
                validate_data=True
            )
            
            result = task.execute(connection)
            
            # Close connection
            connection.close()
            
            # Return success with results
            module.exit_json(**result.to_dict())
        
    except ValueError as e:
        # Validation errors (FR-015)
        log_error(logger, "validation", str(e))
        module.fail_json(msg=f"Validation error: {e}")
        
    except Exception as e:
        # Handle all other errors (FR-015)
        error_type = type(e).__name__
        error_msg = str(e)
        
        # Categorize error for clear messaging
        if 'authentication' in error_msg.lower() or 'incorrect username' in error_msg.lower():
            category = "authentication"
        elif 'syntax' in error_msg.lower() or 'parse' in error_msg.lower():
            category = "syntax"
        elif 'timeout' in error_msg.lower():
            category = "timeout"
        elif 'network' in error_msg.lower() or 'connection' in error_msg.lower():
            category = "network"
        else:
            category = "execution"
        
        log_error(logger, category, error_msg)
        module.fail_json(
            msg=f"{category.upper()} ERROR: {error_msg}",
            error_type=error_type,
            exception=traceback.format_exc()
        )


if __name__ == '__main__':
    main()
