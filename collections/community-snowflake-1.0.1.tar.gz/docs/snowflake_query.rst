=====================================
snowflake_query - Query Snowflake
=====================================

.. contents::
   :local:
   :depth: 2

Synopsis
--------

- Execute SQL queries against Snowflake data warehouse
- Supports SELECT, INSERT, UPDATE, DELETE, and MERGE operations
- Automatic retry logic with exponential backoff for transient errors
- Data validation before write operations
- Secure credential handling with Ansible vault integration
- Structured logging without credential exposure

Requirements
------------

- Python >= 3.9
- snowflake-connector-python >= 3.0.0
- tenacity >= 8.0.0

Parameters
----------

snowflake_account (required)
  Snowflake account identifier (e.g., "abc123.us-east-1")
  
snowflake_user (required)
  Username for Snowflake authentication
  
snowflake_password (required, no_log)
  Password for Snowflake authentication
  Use Ansible vault to encrypt this value
  
snowflake_warehouse (optional)
  Compute warehouse name for query execution
  
snowflake_database (optional)
  Target database name
  
snowflake_schema (optional, default: PUBLIC)
  Target schema name within database
  
snowflake_role (optional)
  Snowflake role for session permissions
  
operation (optional, choices: select/insert/update/delete/merge/execute)
  SQL operation type to execute
  Auto-detected from query if not specified
  
transaction_mode (optional, default: auto, choices: auto/manual)
  Transaction handling mode
  - auto: Commits on success, rollback on error
  - manual: Requires explicit COMMIT/ROLLBACK in query
  
query (optional)
  SQL query text to execute
  Mutually exclusive with query_file
  
query_file (optional)
  Path to file containing SQL query
  Mutually exclusive with query
  
parameters (optional, default: {})
  Named parameters for query parameterization
  Prevents SQL injection by using bind variables
  Use :param_name syntax in query (e.g., WHERE id = :customer_id)
  Supports JSON-serializable types: str, int, float, bool, list, dict, None
  
timeout (optional, default: 30)
  Query timeout in seconds
  
output_format (optional, default: json, choices: json/csv/yaml)
  Format for query results
  
output_file (optional)
  Path to write query results
  Automatically used for large result sets (>10K rows)

Return Values
-------------

changed (always returned)
  Whether the operation modified data
  Type: bool
  
row_count (always returned)
  Number of rows affected or returned
  Type: int
  
execution_time_ms (always returned)
  Query execution duration in milliseconds
  Type: int
  
query_id (always returned)
  Snowflake query ID for debugging
  Type: str
  
rows (returned for SELECT with results in memory)
  Query result rows as list of dictionaries
  Type: list of dict
  
column_metadata (returned for SELECT)
  Schema information for result columns
  Type: list of dict
  
warnings (returned when warnings exist)
  Non-fatal warnings from query execution
  Type: list of str

Examples
--------

Execute SELECT query with vault credentials::

    - name: Query Snowflake customers table
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_warehouse: "COMPUTE_WH"
        snowflake_database: "PROD_DB"
        snowflake_schema: "PUBLIC"
        query: "SELECT * FROM customers WHERE region = 'US-WEST'"
        output_format: json
      register: result

    - debug:
        msg: "Retrieved {{ result.row_count }} rows"

INSERT operation with automatic transaction::

    - name: Insert customer record
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: "INSERT INTO customers (id, name, email) VALUES (1, 'John Doe', 'john@example.com')"
        transaction_mode: auto
      register: insert_result

    - debug:
        msg: "Inserted {{ insert_result.row_count }} rows"
      when: insert_result.changed

UPDATE operation::

    - name: Update customer email
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: "UPDATE customers SET email = 'newemail@example.com' WHERE id = 1"

MERGE (upsert) operation::

    - name: Upsert customer data
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: |
          MERGE INTO customers AS target
          USING (SELECT 1 AS id, 'Jane Doe' AS name, 'jane@example.com' AS email) AS source
          ON target.id = source.id
          WHEN MATCHED THEN UPDATE SET name = source.name, email = source.email
          WHEN NOT MATCHED THEN INSERT (id, name, email) VALUES (source.id, source.name, source.email)

Export results to CSV file::

    - name: Export orders to CSV
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: "SELECT * FROM orders WHERE order_date >= '2026-01-01'"
        output_format: csv
        output_file: "/tmp/orders_export.csv"

Query from SQL file::

    - name: Run complex query from file
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "ANALYTICS_DB"
        query_file: "queries/monthly_report.sql"
        output_format: yaml

Parameterized query (SQL injection prevention)::

    - name: Query with parameters
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: "SELECT * FROM customers WHERE region = :region AND status = :status"
        parameters:
          region: "US-WEST"
          status: "active"
      register: filtered_customers

Parameterized INSERT for safe data insertion::

    - name: Insert with parameters
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: "INSERT INTO customers (id, name, email) VALUES (:id, :name, :email)"
        parameters:
          id: 1001
          name: "John Doe"
          email: "john@example.com"

Environment-specific queries with Ansible variables::

    - name: Environment-aware query
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "{{ environment_database }}"  # DEV_DB or PROD_DB
        query: "SELECT * FROM customers WHERE region = :region"
        parameters:
          region: "{{ target_region }}"

Handle empty result set::

    - name: Run complex query from file
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "ANALYTICS_DB"
        query_file: "queries/monthly_report.sql"
        output_format: yaml

Handle empty result set::

    - name: Search for specific customer
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_database: "PROD_DB"
        query: "SELECT * FROM customers WHERE id = 99999"
      register: search_result
    
    - debug:
        msg: "Customer not found"
      when: search_result.row_count == 0

Status
------

- Feature: 001-ansible-snowflake-automation
- User Stories: US1 (P1 MVP) Read, US2 (P2) Write, US3 (P3) Parameterization
- Status: Implemented
- Version: 1.0.0

SQL Injection Prevention
------------------------

Always use parameter binding with :param_name syntax for user-provided values:

**UNSAFE** (vulnerable to SQL injection)::

    query: "SELECT * FROM users WHERE username = '{{ user_input }}'"

**SAFE** (parameter binding)::

    query: "SELECT * FROM users WHERE username = :username"
    parameters:
      username: "{{ user_input }}"

Parameter binding ensures:
- Automatic escaping of special characters
- Type validation
- Protection against malicious SQL injection
- Reusable query templates

Author
------

Data Engineering Team

Copyright
---------

Copyright (c) 2026
GNU General Public License v3.0+
