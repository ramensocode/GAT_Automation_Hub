# Ansible Snowflake Collection

This is the official Ansible Collection for Snowflake data warehouse automation.

## Installation

### From Ansible Galaxy

```bash
ansible-galaxy collection install community.snowflake
```

### From Source

```bash
# Build the collection
ansible-galaxy collection build

# Install the built collection
ansible-galaxy collection install community-snowflake-*.tar.gz
```

## Usage

Once installed, you can use the collection in your playbooks:

```yaml
---
- hosts: localhost
  collections:
    - community.snowflake
  tasks:
    - name: Query Snowflake
      snowflake_query:
        snowflake_account: "{{ snowflake_account }}"
        snowflake_user: "{{ snowflake_user }}"
        snowflake_password: "{{ vault_snowflake_password }}"
        snowflake_warehouse: "COMPUTE_WH"
        snowflake_database: "PROD_DB"
        snowflake_schema: "PUBLIC"
        query: "SELECT * FROM customers LIMIT 10"
        output_format: json
      register: result
```

### Bulk Insert from CSV

```yaml
- name: Bulk load data from CSV
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_database: "PROD_DB"
    query: "INSERT INTO orders (id, customer, amount) VALUES (:id, :customer, :amount)"
    input_file: "/data/orders.csv"
    csv_has_header: true
    csv_delimiter: ","
  register: result

- debug:
    msg: "Loaded {{ result.row_count }} rows in {{ result.execution_time_ms }}ms"
```

### Bulk Insert from JSON

```yaml
- name: Bulk load data from JSON
  snowflake_query:
    snowflake_account: "{{ snowflake_account }}"
    snowflake_user: "{{ snowflake_user }}"
    snowflake_password: "{{ vault_snowflake_password }}"
    snowflake_database: "PROD_DB"
    query: "INSERT INTO orders (id, customer, amount) VALUES (:id, :customer, :amount)"
    input_file: "/data/orders.json"
    input_format: json
  register: result
```

## Modules

### `snowflake_query`

Execute SQL queries against Snowflake with retry logic, data validation, and bulk import capabilities.

**Key Features:**
- Single and bulk INSERT/UPDATE/DELETE operations
- CSV and JSON file import (auto-detected or specified format)
- Parameterized queries with SQL injection prevention
- Automatic retry with exponential backoff
- Transaction management (auto or manual)
- Detailed error reporting per row for bulk operations

**Bulk Operation Parameters:**
- `input_file` - Path to CSV or JSON file
- `input_format` - File format (`csv` or `json`, auto-detected from extension)
- `csv_delimiter` - CSV delimiter character (default: `,`)
- `csv_has_header` - Whether CSV has header row (default: `true`)

## Documentation

- See [docs/](docs/) for module documentation
- See [playbooks/examples/](playbooks/examples/) for usage examples
- See [../TEST_Examples/](../TEST_Examples/) for bulk import examples
- See [galaxy.yml](galaxy.yml) for collection metadata
- See [../specs/001-ansible-snowflake-automation/](../specs/001-ansible-snowflake-automation/) for detailed specifications

## Testing

Tests are maintained in the [collection-dev/](../collection-dev/) directory (not included in the distributed collection):

```bash
# Run integration tests
cd ../collection-dev
ansible-test integration snowflake_query

# Run unit tests
pytest tests/unit/
```

See [collection-dev/README.md](../collection-dev/README.md) for detailed testing instructions.

## Collection Structure

This collection includes only the essential files for distribution:

```
collection/
├── galaxy.yml              # Collection metadata
├── README.md               # This file
├── plugins/
│   ├── modules/           # Ansible modules (snowflake_query)
│   └── module_utils/      # Shared utilities for modules
├── docs/                  # Module documentation (.rst files)
└── playbooks/examples/    # Example playbooks for users
```

**Note**: Tests and development files are in `collection-dev/` and excluded from the build via `build_ignore` in `galaxy.yml`.

## License

MIT License - See LICENSE file for details

## Support

For issues and questions:
- GitHub Issues: See parent repository
- Documentation: Check the [docs/](docs/) directory
